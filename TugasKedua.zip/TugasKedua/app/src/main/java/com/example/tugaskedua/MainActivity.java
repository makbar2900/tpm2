package com.example.tugaskedua;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private final String NAMA = "NAMA";
    private final String NIM = "NIM";
    private final String NILAI = "NILAI";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnSubmit = findViewById(R.id.btntombol);
        EditText InUser = findViewById(R.id.inuser);
        EditText InNIM = findViewById(R.id.innim);
        EditText InNilai = findViewById(R.id.innilai);

        btnSubmit.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                try {
                    String nama    = InUser.getText().toString();
                    String nim     = InNIM.getText().toString();
                    String skor    = InNilai.getText().toString();
                    Intent i = new Intent(MainActivity.this, OutputActivity.class);
                    i.putExtra(NAMA, nama);
                    i.putExtra(NIM, nim);
                    double nilai   = Double.parseDouble(skor);

                    if(nilai <= 4.00){
                        if(nilai > 3.66 && nilai <= 4.00){
                            i.putExtra(NILAI, "A");
                        }else if(nilai > 3.33 && nilai <= 3.66) {
                            i.putExtra(NILAI, "A-");
                        }else if(nilai > 3.00 && nilai <= 3.33) {
                            i.putExtra(NILAI, "B+");
                        }else if(nilai > 2.66 && nilai <= 3.00) {
                            i.putExtra(NILAI, "B");
                        }else if(nilai > 2.33 && nilai <= 2.66) {
                            i.putExtra(NILAI, "B-");
                        }else if(nilai > 2.00 && nilai <= 2.33) {
                            i.putExtra(NILAI, "C+");
                        }else if(nilai > 1.66 && nilai <= 2.00) {
                            i.putExtra(NILAI, "C");
                        }else if(nilai > 1.33 && nilai <= 1.66) {
                            i.putExtra(NILAI, "C-");
                        }else if(nilai > 1.00 && nilai <= 1.33) {
                            i.putExtra(NILAI, "D+");
                        }else {
                            i.putExtra(NILAI, "D");
                        }
                        startActivity(i);
                    }else {
                        Toast.makeText(getApplication(), "Masukkan Nilai 0 - 4", Toast.LENGTH_SHORT).show();
                    }

                }
                catch (Exception e) {
                    e.printStackTrace();
                    Toast.makeText(getApplication(), "Isi Field Terlebih dahulu", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

}
